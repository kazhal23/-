const words = {
  animals: ["گربه", "سگ", "فیل", "ببر", "زرافه", "کانگورو", "گورخر", "دلفین", "پنگوئن", "شیر"],
  flowers: ["رز", "لاله", "بابونه", "مریم", "ارکیده", "سوسن", "ماریگلد", "اسطوخودوس", "شقایق", "بنفشه"],
  food: ["پیتزا", "همبرگر", "پاستا", "سوشی", "استیک", "پنکیک", "املت", "ساندویچ", "چیزکیک", "بریانی"],
  music: ["گیتار", "ویولن", "پیانو", "درام", "ترومپت", "فلوت", "ساکسوفون", "چلو", "هارمونیکا", "بانجو"],
  books: ["رمان", "شعر", "بیوگرافی", "معما", "فانتزی", "هیجانی", "رومانتیک", "علمی", "تاریخ", "ماجراجویی"]
};
let selectedCategory = "";
let selectedWord = "";
let guessedLetters = [];
let wrongGuesses = 0;
let score = 0;
let round = 1;
const maxWrongGuesses = 6;
const maxRounds = 5;
let usedWords = {
  animals: [],
  flowers: [],
  food: [],
  music: [],
  books: []
};
const figureParts = document.querySelectorAll('.figure-part');
function startGame(category) {
  if (round > maxRounds) {
    document.getElementById("finalMessage").style.display = "block";
    document.getElementById("finalScore").textContent = `امتیاز کل شما: ${score} ⭐`;
    return;
  }
  selectedCategory = category;
  let availableWords = words[category].filter(word => !usedWords[category].includes(word));
  if (availableWords.length === 0) {
    usedWords[category] = [];
    availableWords = [...words[category]];
  }
  selectedWord = availableWords[Math.floor(Math.random() * availableWords.length)];
  usedWords[category].push(selectedWord);
  guessedLetters = Array(selectedWord.length).fill("_");
  wrongGuesses = 0;
  figureParts.forEach(part => part.style.display = "none");
  updateDisplay();
  document.getElementById("answerDisplay").textContent = "";
  document.getElementById("scoreDisplay").textContent = `Round: ${round}/5 | Score: ${score} ⭐`;
}
function updateDisplay() {
  document.getElementById("wordDisplay").textContent = guessedLetters.join(" ");
}
function guessLetter(letter) {
  if (selectedWord.includes(letter)) {
    for (let i = 0; i < selectedWord.length; i++) {
      if (selectedWord[i] === letter) guessedLetters[i] = letter;
    }
  } else {
    wrongGuesses++;
    document.getElementById("hangmanContainer").classList.add("shake");
    setTimeout(() => document.getElementById("hangmanContainer").classList.remove("shake"), 500);
    figureParts.forEach((part, index) => {
      part.style.display = index < wrongGuesses ? "block" : "none";
    });
  }
  checkGameStatus();
  updateDisplay();
}
function checkGameStatus() {
  if (!guessedLetters.includes("_")) {
    document.getElementById("answerDisplay").textContent = `🎉 آفرین! دور را کامل کردی ${round}!`;
    score += 1;
    if (round < maxRounds) {
      round++;
      setTimeout(() => startGame(selectedCategory), 1500);
    } else {
      document.getElementById("finalMessage").style.display = "block";
      document.getElementById("finalScore").textContent = `امتیاز کل شما: ${score} ⭐`;
    }
  } else if (wrongGuesses >= maxWrongGuesses) {
    document.getElementById("answerDisplay").textContent = `❌ متاسفانه اشتباه بود "${selectedWord}"`;
    round = maxRounds;
    setTimeout(() => {
      document.getElementById("finalMessage").style.display = "block";
      document.getElementById("finalScore").textContent = `امتیاز کل شما: ${score} ⭐`;
    }, 1500);
  }
}
document.getElementById("letterInput").addEventListener("input", function () {
  const letter = this.value;
  if (letter.match(/[\u0600-\u06FF]/) && letter.length === 1) {
    guessLetter(letter);
  }
  this.value = "";
});
document.getElementById("startAnimals").addEventListener("click", () => startGame("animals"));
document.getElementById("startFlowers").addEventListener("click", () => startGame("flowers"));
document.getElementById("startFood").addEventListener("click", () => startGame("food"));
document.getElementById("startMusic").addEventListener("click", () => startGame("music"));
document.getElementById("startBooks").addEventListener("click", () => startGame("books"));
